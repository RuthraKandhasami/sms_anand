﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_DAL;
using SMS_Exception;
using SMS_Entity;

namespace SMS_BL
{
    public class StudentBl
    {
        StudentDAL dal = new StudentDAL();

        public void Add(Student student)
        {
            try
            {
                dal.Insert(student);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Modify(Student student)
        {
            try
            {
                dal.Update(student);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
