﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_BL;
using SMS_DAL;
using SMS_Exception;
using SMS_Entity;

namespace SMS_Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBl objbl = new StudentBl();

        public MainWindow()
        {
            InitializeComponent();
            objbl = new StudentBl(); 
        }

        private bool ValidateUi(string fullname, string dob, string contact, string email, string gender,string state,string address)
        {
            bool sts = true;
            StringBuilder sb = new StringBuilder();

            if (fullname == null || fullname == string.Empty)
            {
                sts = false;
                sb.Append("Name is Empty!" + Environment.NewLine);
            }
            if (dob == null || dob == string.Empty)
            {
                sts = false;
                sb.Append("DOB is Empty!" + Environment.NewLine);
            }
            if (contact == null || contact == string.Empty)
            {
                sts = false;
                sb.Append("Contact is Empty!" + Environment.NewLine);
            }
            if (email == null || email == string.Empty)
            {
                sts = false;
                sb.Append("Email id is Empty!" + Environment.NewLine);
            }
            if (gender == null || gender == string.Empty)
            {
                sts = false;
                sb.Append("Gender is Empty!" + Environment.NewLine);
            }
            if (state == null || state == string.Empty)
            {
                sts = false;
                sb.Append("State is Empty!" + Environment.NewLine);
            }
            if (address == null || address == string.Empty)
            {
                sts = false;
                sb.Append("Address is Empty!" + Environment.NewLine);
            }
            if (sts == false)
                throw new SMSException(sb.ToString());
           else
            return sts;
        }

        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string gender = string.Empty;
                if (rdm.IsChecked == true)
                    gender = rdm.Content.ToString();
                else if (rdfm.IsChecked == true)
                    gender = rdfm.Content.ToString();

                txt6.SelectAll();

                if (ValidateUi(txt1.Text, cln1.SelectedDate.ToString(), txt3.Text, txt4.Text,gender, ((ListBoxItem)txt5.SelectedItem).Content.ToString(),txt6.ToString()))
                {
                    Student objstudent = new Student
                    {
                        FullName = txt1.Text,
                        DOB = (DateTime)cln1.SelectedDate,
                        Contact = txt3.Text,
                        Emailid = txt4.Text,
                        ResidentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString()
                    };                    
                    objstudent.Gender = gender;
                    objstudent.CommunicationAddress = txt6.Selection.Text;
                    objbl.Add(objstudent);
                    MessageBox.Show("Inserted successfully!!");
                }
                else
                {
                    MessageBox.Show("Validation failed");
                }
            }           
            catch(SMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }
       
    }
}
