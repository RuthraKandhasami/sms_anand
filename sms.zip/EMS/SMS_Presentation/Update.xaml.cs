﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS_DAL;
using SMS_Entity;
using SMS_Exception;
using SMS_BL;

namespace SMS_Presentation
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        StudentBl objbl = new StudentBl();
        public Update()
        {
            InitializeComponent();
            objbl = new StudentBl();
        }

        private void Btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                   Student objstudent = new Student
                    {
                        FullName = txt1.Text,
                        DOB = (DateTime)cln1.SelectedDate,
                        Contact = txt3.Text,
                        Emailid = txt4.Text,
                        ResidentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString()
                    };
                string gender = string.Empty;
                if (rdm.IsChecked == true)
                    gender = rdm.Content.ToString();
                else if (rdfm.IsChecked == true)
                    gender = rdfm.Content.ToString();
                objstudent.Gender = gender;
                txt6.SelectAll();
                objstudent.CommunicationAddress = txt6.Selection.Text;
                objbl.Modify(objstudent);
                MessageBox.Show("Updated!!");
            }
            catch (SMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {          
            
        }
    }
}

