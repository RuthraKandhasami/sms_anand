﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SMS_Entity;
using SMS_Exception;

namespace SMS_DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
        }

        public void Insert(Student objstudent)
        {
            try
            {
                cmd = new SqlCommand("insert into [SMS].Student values(@sName,@gender,@sdob,@scontact,@semail,@state,@sadd)", cn);
                cmd.Parameters.AddWithValue("@sName", objstudent.FullName);
                cmd.Parameters.AddWithValue("@gender", objstudent.Gender);
                cmd.Parameters.AddWithValue("@sdob", objstudent.DOB);
                cmd.Parameters.AddWithValue("@scontact", objstudent.Contact);
                cmd.Parameters.AddWithValue("@semail", objstudent.Emailid);
                cmd.Parameters.AddWithValue("@state", objstudent.ResidentialState);
                cmd.Parameters.AddWithValue("@sadd", objstudent.CommunicationAddress);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if(cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public void Update(Student objstudent)
        {
            try
            {
                cmd = new SqlCommand("Update [SMS].Student set FullName = @sName,Gender = @gender, DOB = @sdob,Contact = @scontact,Emailid = @semail, ResidentialState = @state,CommunicationAddress = @sadd where RollNo = @rno", cn);
                cmd.Parameters.AddWithValue("@rno", objstudent.Rollno);
                cmd.Parameters.AddWithValue("@sName", objstudent.FullName);
                cmd.Parameters.AddWithValue("@gender", objstudent.Gender);
                cmd.Parameters.AddWithValue("@sdob", objstudent.DOB);
                cmd.Parameters.AddWithValue("@scontact", objstudent.Contact);
                cmd.Parameters.AddWithValue("@semail", objstudent.Emailid);
                cmd.Parameters.AddWithValue("@state", objstudent.ResidentialState);
                cmd.Parameters.AddWithValue("@sadd", objstudent.CommunicationAddress);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
    }
}

