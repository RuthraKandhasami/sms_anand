﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_DataAccessLayer;
using SMS_BusinessLayer;
using SMS_Entities;
using SMS_Exceptions;


namespace StudentMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        StudentBL studentBL = new StudentBL();

        public MainWindow()
        {
            InitializeComponent();
            //populate();

        }

        public void clear()
        {
            DOB.Text = txtId.Text =txtname.Text = txtphone.Text = txtemail.Text = txtaddress.Selection.Text = string.Empty;
            rbtnFemale.IsChecked = false;
            rbtnMale.IsChecked = false;
            state.SelectedIndex = 0;
        }



        private void SubmitBtn_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.StuName = txtname.Text;
                if (rbtnMale.IsChecked == true)
                {
                    student.StuGender = rbtnMale.Content.ToString();
                }
                else
                {
                    student.StuGender = rbtnFemale.Content.ToString();
                }
                student.DOB = (DateTime)DOB.SelectedDate;
                student.MobileNo = txtphone.Text;
                student.Email = txtemail.Text;

                txtaddress.SelectAll();
                student.Comm_Address = txtaddress.Selection.Text;

               student.state = ((ListBoxItem)state.SelectedItem).Content.ToString();

                int id;
                id = studentBL.InsertBL(student);
                MessageBox.Show("record Inserted rollno =" + id);
                clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int stuid = int.Parse(txtId.Text);
                Student student = studentBL.SearchBL(stuid);

                txtId.Text = student.StuID.ToString();

                txtname.Text = student.StuName.ToString();

                String gender = student.StuGender;
                if (gender == "Male")
                {
                    rbtnMale.IsChecked = true;
                }
                else if (gender == "Female")
                {
                    rbtnFemale.IsChecked = true;
                }

                DOB.Text = student.DOB.ToShortDateString().ToString();

                txtphone.Text = student.MobileNo.ToString();

                txtemail.Text = student.Email.ToString();

                txtaddress.Document.Blocks.Clear();
                txtaddress.Document.Blocks.Add(new Paragraph(new Run (student.Comm_Address)));

               foreach (ListBoxItem lbi in state.Items)
               {
                    if (lbi.Content.ToString() == student.state.ToString())
                    {
                        lbi.IsSelected = true;
                    }
               }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.StuID = Convert.ToInt32(txtId.Text);
                studentBL.DeleteBL(student.StuID);
                MessageBox.Show("record Deleted");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.StuID = Convert.ToInt32( txtId.Text);
                student.StuName = txtname.Text;
                if (rbtnMale.IsChecked == true)
                {
                    student.StuGender = rbtnMale.Content.ToString();
                }
                else
                {
                    student.StuGender = rbtnFemale.Content.ToString();
                }
                student.DOB = (DateTime)DOB.SelectedDate;
                student.MobileNo = txtphone.Text;
                student.Email = txtemail.Text;

                txtaddress.SelectAll();
                student.Comm_Address = txtaddress.Selection.Text;

                student.state = ((ListBoxItem)state.SelectedItem).Content.ToString();


                studentBL.UpdateBL(student);
                MessageBox.Show("record updated");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //public void populate()
        //{
        //    try
        //    {
        //        List<Student> studs = studentBL.SelectAllBL();
        //        dgStudents.ItemsSource = studs;
        //    }
        //    catch (Exception ex1)
        //    {
        //        MessageBox.Show(ex1.Message);
        //    }
        //}

    }
}
