﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entities;
using SMS_Exceptions;
using System.Data.SqlClient;
using System.Configuration;


namespace SMS_DataAccessLayer
{
    public class StudentDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        }

        public int insert(Student student)
        {
            int Student_id;
            try
            {
                //cmd = new SqlCommand("insert into At189753.Student values(@Stu_Name,@Stu_Gender,@Stu_DOB,@Stu_MobileNo,@Stu_Email,@Stu_Address,@Stu_State) ", con);
                cmd = new SqlCommand("[At189753].[USP_Insert_Student]", con);
                SqlParameter stuid = new SqlParameter("@stu_id", System.Data.SqlDbType.Int);
                stuid.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(stuid);

                cmd.Parameters.AddWithValue("@Stu_Name", student.StuName);
                cmd.Parameters.AddWithValue("@Stu_Gender", student.StuGender);
                cmd.Parameters.AddWithValue("@Stu_DOB", student.DOB);
                cmd.Parameters.AddWithValue("@Stu_MobileNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@Stu_Email", student.Email);
                cmd.Parameters.AddWithValue("@Stu_Address", student.Comm_Address);
                cmd.Parameters.AddWithValue("@Stu_State", student.state);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                cmd.ExecuteNonQuery();
                Student_id = Convert.ToInt32(cmd.Parameters["@stu_id"].Value);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                if(con.State == System.Data.ConnectionState.Open )
                con.Close();
            }
            return Student_id;
        }

        public void update(Student student)
        {
            try
            {
                //cmd = new SqlCommand("update At189753.Student set Stu_Name = @Stu_Name , Stu_Gender = @Stu_Gender, Stu_DOB = @Stu_DOB, Stu_MobileNo = @Stu_MobileNo, Stu_Email = @Stu_Email, Stu_Address = @Stu_Address, Stu_State = @Stu_State where Stu_Id = @Stu_Id ", con);
                cmd = new SqlCommand("[At189753].[USP_Update_Student]", con);
                cmd.Parameters.AddWithValue("@Stu_Name", student.StuName);
                cmd.Parameters.AddWithValue("@Stu_Gender", student.StuGender);
                cmd.Parameters.AddWithValue("@Stu_DOB", student.DOB);
                cmd.Parameters.AddWithValue("@Stu_MobileNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@Stu_Email", student.Email);
                cmd.Parameters.AddWithValue("@Stu_Address", student.Comm_Address);
                cmd.Parameters.AddWithValue("@Stu_State", student.state);
                cmd.Parameters.AddWithValue("@Stu_Id", student.StuID);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                cmd.ExecuteNonQuery();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
        }

        public void delete(int studentID)
        {
           
            try
            {
                //cmd = new SqlCommand("delete from At189753.Student where Stu_Id = @Stu_Id ", con);
                cmd = new SqlCommand("[At189753].[USP_Delete_Student]", con);
                
                cmd.Parameters.AddWithValue("@Stu_Id", studentID);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
        }

        public Student search(int stuid)
        {
            Student student = new Student();
            try
            {
                cmd = new SqlCommand("select * from At189753.Student  where Stu_id = @Stuid ", con);
                cmd.Parameters.AddWithValue("@Stuid", stuid);
                con.Open();
                dr = cmd.ExecuteReader();
                if(dr.Read()) // instead of while we are using if because it will return only one value , while is use to return multiplaye values 
                {
                    student.StuID = Convert.ToInt32(dr[0]);
                    student.StuName = dr[1].ToString();
                    student.StuGender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.Comm_Address = dr[6].ToString();
                    student.state = dr[7].ToString();

                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return student;
        }

        public List<Student> SelectAll()
        {
            List<Student> students = new List<Student>();
            try
            {
                cmd = new SqlCommand("select * from At189753.Student ", con);
                //cmd.CommandType = System.Data.CommandType.StoredProcedure; //store procedure for delect all
                //cmd.Parameters.AddWithValue("@Stuid",);
                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read()) // instead of while we are using if because it will return only one value , while is use to return multiplaye values 
                {
                    Student student = new Student();

                    student.StuID = Convert.ToInt32(dr[0]);
                    student.StuName = dr[1].ToString();
                    student.StuGender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.Comm_Address = dr[6].ToString();
                    student.state = dr[7].ToString();

                    students.Add(student);
                  
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return students;
        }
    }
}
