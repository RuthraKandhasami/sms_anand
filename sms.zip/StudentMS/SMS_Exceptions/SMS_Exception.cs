﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Exceptions
{
    public class SMS_Exception : ApplicationException
    {
        public SMS_Exception () :base()
        {

        }
        public SMS_Exception(string Message) :base(Message)
        {

        }
    }
}
