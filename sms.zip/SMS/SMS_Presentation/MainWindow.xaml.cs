﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_Entity;
using SMS_Exception;
using SMS_DAL;
using SMS_BL;

namespace SMS_Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBL bal = new StudentBL();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student student = new Student
                {
                    FullName = txt1.Text,
                    DOB = (DateTime)txt2.SelectedDate,
                    Contact = txt3.Text,
                    Emailid = txt4.Text,
                    ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString()
                };
                string gender = string.Empty;
                if (Male.IsChecked == true)
                    gender = Male.Content.ToString();
                else if (Female.IsChecked == true)
                    gender = Female.Content.ToString();
                student.Gender = gender;
                txt6.SelectAll();
                student.CommunicationAddress = txt6.Selection.Text;
                bal.Add(student);
                MessageBox.Show("Record Inserted Successfully!");
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

    }
}
