﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS_BL;
using SMS_DAL;
using SMS_Entity;
using SMS_Exception;

namespace SMS_Presentation
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        StudentBL bal = new StudentBL();
        public Update()
        {
            InitializeComponent();
        }

        private void Btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student student = new Student
                {
                    RollNo = Convert.ToInt32(txt.Text),
                    FullName = txt1.Text,
                    DOB = (DateTime)txt2.SelectedDate,
                    Contact = txt3.Text,
                    Emailid = txt4.Text,
                    ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString()
                };
                string gender = string.Empty;
                if (Male.IsChecked == true)
                    gender = Male.Content.ToString();
                else if (Female.IsChecked == true)
                    gender = Female.Content.ToString();
                student.Gender = gender;
                txt6.SelectAll();
                student.CommunicationAddress= txt6.Selection.Text;
                StudentBL.modify(student);
                MessageBox.Show("Record Updated Successfully!");
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rollno = int.Parse(txt.Text);
                Student student = bal.Search(rollno);
                txt.Text = student.RollNo.ToString();
                txt1.Text = student.FullName;
                if(student.Gender == "Male")
                {
                    Male.IsChecked = true;
                }
                else if (student.Gender == "Female")
                {
                    Female.IsChecked = true;
                }
                txt2.Text = student.DOB.ToString();
                txt3.Text = student.Contact;
                txt4.Text = student.Emailid;
                foreach (ListBoxItem list in txt5.Items)
                {
                    if (list.Content.ToString() == student.ResedentialState)
                    {
                        list.IsSelected = true;
                    }
                }
                txt6.Document.Blocks.Clear();
                txt6.Document.Blocks.Add(new Paragraph(new Run(student.CommunicationAddress)));
            }
            catch(Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Student> studs = bal.view();
                dg.ItemsSource = studs;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }
    }
}
