﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;
using SMS_Exception;
using SMS_DAL;

namespace SMS_BL
{
    public class StudentBL
    {
        StudentDAL dal = new StudentDAL();

        public int Add(Student student)
        {
            int rollno;
            try
            {
                rollno = dal.Insert(student);
            }
            catch (Exception)
            {
                throw;
            }
            return rollno;
        }

        public static void modify(Student student)
        {
            try
            {
                StudentDAL.Update(student);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Student Search(int rollno)
        {
            Student student = null;
            try
            {
                student = dal.SelectBy(rollno);
            }
            catch (Exception)
            {
                throw;
            }
            return student;
        }

        public List<Student> view()
        {
            List<Student> student = null;
            try
            {
                student = dal.SelectAll();
            }
            catch (Exception)
            {
                throw;
            }
            return student;
        }
    }
}
