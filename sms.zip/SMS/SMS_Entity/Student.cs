﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entity
{
    public class Student
    {
        public int RollNo { get; set; }
        public string FullName { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public string Contact { get; set; }
        public string Emailid { get; set; }
        public string ResedentialState { get; set; }
        public string CommunicationAddress { get; set; }
    }
}
