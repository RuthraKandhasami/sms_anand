﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;

namespace SMS_Exception
{
    public class StudentException : ApplicationException
    {
        public StudentException() : base()
        {
        }

        public StudentException(string msg) : base(msg)
        {
        }

    }
}
