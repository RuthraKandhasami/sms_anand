﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SMS_Entity;
using SMS_Exception;
using System.Configuration;

namespace SMS_DAL
{
    public class StudentDAL
    {
        static SqlConnection cn = null;
        static SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public int Insert(Student student)
        {
            int rollno;
            try
            {
                cmd = new SqlCommand("[190305].USP_InsertStudent", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter rno = new SqlParameter("@rollno", System.Data.SqlDbType.Int);
                rno.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(rno);
                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.Contact);
                cmd.Parameters.AddWithValue("@email", student.Emailid);
                cmd.Parameters.AddWithValue("@state", student.ResedentialState);
                cmd.Parameters.AddWithValue("@add", student.CommunicationAddress);               
                cn.Open();
                cmd.ExecuteNonQuery();
                rollno = Convert.ToInt32(cmd.Parameters["@rollno"].Value);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return rollno;
        }

        public static void Update(Student student)
        {
            try
            {
                cmd = new SqlCommand("Update [190305].Student set FullName=@fullName,Gender=@gender,Emailid=@email,CommunicationAddress=@add,DOB=@dob,Contact=@mobNo,ResidentialState =@state Where Rollno=@rollno", cn);
                cmd.Parameters.AddWithValue("@rollno", student.RollNo);
                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.Contact);
                cmd.Parameters.AddWithValue("@email", student.Emailid);
                cmd.Parameters.AddWithValue("@state", student.ResedentialState);
                cmd.Parameters.AddWithValue("@add", student.CommunicationAddress);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        public Student SelectBy(int rollNo)
        {
            Student student = new Student();
            try
            {
                cmd = new SqlCommand("Select * from Student where Rollno =@rollno", cn);
                cmd.Parameters.AddWithValue("@rollno",rollNo);
                cn.Open();
                dr = cmd.ExecuteReader();
                if(dr.Read())
                {
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.Contact = dr[4].ToString();
                    student.Emailid = dr[5].ToString();
                    student.ResedentialState = dr[6].ToString();
                    student.CommunicationAddress = dr[7].ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cn.Close();
                dr.Close();
            }
            return student;
        }

        public List<Student> SelectAll()
        {
            List<Student> listst = new List<Student>();
            try
            {           
                cmd = new SqlCommand("[190305].USP_ViewStudent", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Student student = new Student();
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.Contact = dr[4].ToString();
                    student.Emailid = dr[5].ToString();
                    student.ResedentialState = dr[6].ToString();
                    student.CommunicationAddress = dr[7].ToString();
                    listst.Add(student);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cn.Close();
                dr.Close();
            }
            return listst;
        }

    }
}
